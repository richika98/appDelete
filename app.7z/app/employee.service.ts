import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Data } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  http:HttpClient; //do
  employees:Department[]=[]; //do 
  constructor(http:HttpClient) {  //do
    this.http=http; //do globally read data 
  }
  fetched:boolean=false;
  fetchdepartment() { //read data from employes.json and store in data
    this.http.get('./assets/Employee.json') //get files data read data
    
    .subscribe(
      data=>{
        if(!this.fetched){
          this.convert(data);
          this.fetched=true;
        }
      }
    );
    }
  
delete(did:number){
  let d:Department;
  let indexfound=-1;
  for(let i=0;i<this.employees.length;i++  )
  {
   d = this.employees[i];
    if(did==d.dptId)
      {
        indexfound=i;
        break;
      }
  }
  this.employees.splice(indexfound,1);


}

  getEmployee():Department[]{ 
    return this.employees;
  }
  convert(data:any){
    for(let o of data){
      let e=new Department(o.dptId,o.dptName);
      this.employees.push(e);
    }
  }
}

export class Department{
  dptId:number;
  dptName:string;
  constructor(
   dptId:number,dptName:string)
    {
      this.dptId=dptId;
      this.dptName=dptName;
    }

}