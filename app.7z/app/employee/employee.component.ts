import { Component, OnInit } from '@angular/core';
import { Department, EmployeeService } from '../employee.service';
import { SortingPipe } from '../sorting.pipe';
import { __spreadArrays } from 'tslib';

@Component({
  selector: 'department',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  dept:Department[]=[];

  service:EmployeeService;
  constructor(service:EmployeeService) { 
    this.service=service;
  }
  delete(did:number){
    this.service.delete(did);
    this.dept=this.service.getEmployee();
  }


sortById(){

}

sortByName(){

  this.dept.sort();
}


  ngOnInit() {
    this.service.fetchdepartment();
    this.dept=this.service.getEmployee();
  }

}
